// src/StorefrontPublicView.jsx
import React, { useEffect, useState, useMemo } from 'react';
import { useParams } from 'react-router-dom';
import { MessageCircle, ArrowLeft } from 'lucide-react';
import { ref, get } from 'firebase/database';
import { db } from './firebase';
import ProductCard from './ProductCard';
import {
  // standardizeSellerData, // ❌ not needed anymore
  getProductImageUrl,
  formatProductForDisplay,
  formatPrice,
  trackInteraction,
  createWhatsAppMessage,
  generateWhatsAppUrl,
  isMobileDevice,
} from './sharedUtils';

// Marketing / signup URL (placeholder)
const SHOPLINK_SIGNUP_URL = '/';

const StorefrontPublicView = () => {
  const { sellerId } = useParams();

  const [sellerData, setSellerData] = useState(null);
  const [favorites, setFavorites] = useState(new Set());
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [sortBy, setSortBy] = useState('newest');

  const [selectedProduct, setSelectedProduct] = useState(null);
  const [showProductModal, setShowProductModal] = useState(false);

  const [contactNotification, setContactNotification] = useState({
    show: false,
    product: null,
  });

  // Header detail popovers
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [showDeliveryModal, setShowDeliveryModal] = useState(false);

  // Image helpers (used in modal)
  const [lowResImages, setLowResImages] = useState({});
  const PLACEHOLDER =
    'data:image/svg+xml;utf8,' +
    encodeURIComponent(
      `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="600">
         <defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
           <stop offset="0" stop-color="#eef2ff"/><stop offset="1" stop-color="#e0f2fe"/></linearGradient></defs>
         <rect width="100%" height="100%" fill="url(#g)"/>
         <g fill="#64748b" font-family="Arial, Helvetica, sans-serif">
           <text x="50%" y="46%" font-size="28" text-anchor="middle">No Image</text>
           <text x="50%" y="56%" font-size="14" text-anchor="middle">Upload a clear 1200×900 image</text>
         </g>
       </svg>`
    );
  const MIN_W = 600, MIN_H = 600;

  const handleImageLoad = (productId, e) => {
    const { naturalWidth: w, naturalHeight: h } = e.currentTarget;
    if (w < MIN_W || h < MIN_H) {
      setLowResImages((prev) => ({ ...prev, [productId]: true }));
    }
  };
  const handleImageError = (e) => {
    e.currentTarget.src = PLACEHOLDER;
  };

  // Optional: floating chat FAB
  const [showChatFab, setShowChatFab] = useState(false);
  useEffect(() => {
    const onScroll = () => {
      if (window.innerWidth > 768) setShowChatFab(true);
      else setShowChatFab(window.scrollY > 300);
    };
    onScroll();
    window.addEventListener('scroll', onScroll);
    window.addEventListener('resize', onScroll);
    return () => {
      window.removeEventListener('scroll', onScroll);
      window.removeEventListener('resize', onScroll);
    };
  }, []);

  // Load seller profile (public) + products (public)
  useEffect(() => {
    const loadStorefront = async () => {
      if (!sellerId) return;
      try {
        // ✅ Read ONLY the public profile subpath
        const profileRef = ref(db, `users/${sellerId}/profile`);
        const profileSnap = await get(profileRef);
        if (!profileSnap.exists()) {
          setError('Store not found');
          setLoading(false);
          return;
        }

        const p = profileSnap.val() || {};
        const normalizedProfile = {
          storeName: p.storeName || 'Store',
          location: [p.city, p.country].filter(Boolean).join(', ') || 'Online Store',
          currency: p.currency || 'GHS',
          storeDescription: p.storeDescription || p.description || '',
          paymentMethods: p.paymentMethods || p.payments || p.paymentOptions || [],
          deliveryOptions: p.deliveryOptions || p.shippingOptions || p.deliveryMethods || [],
          whatsappNumber: p.whatsappNumber || '',
          bannerUrl: p.bannerUrl || p.coverImageUrl || '',
        };
        setSellerData(normalizedProfile);

        // ✅ Read ONLY the public products subpath
        const productsRef = ref(db, `users/${sellerId}/products`);
        const prodSnap = await get(productsRef);
        if (prodSnap.exists()) {
          const productsData = prodSnap.val();
          const productsArray = Object.entries(productsData).map(([id, data]) => ({
            productId: id,
            ...formatProductForDisplay(data),
          }));

          const activeProducts = productsArray
            .filter((pp) => pp.status === 'active' && pp.quantity > 0)
            .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));

          const uniqueProducts = activeProducts.filter(
            (p, i, self) => self.findIndex((pp) => pp.name === p.name) === i
          );

          setProducts(uniqueProducts);
          setFilteredProducts(uniqueProducts);
        }
      } catch (err) {
        console.error('Error loading storefront:', err);
        setError('Failed to load store');
      } finally {
        setLoading(false);
      }
    };
    loadStorefront();
  }, [sellerId]);

  // Filters/sort
  useEffect(() => {
    let filtered = [...products];
    const s = searchTerm.trim().toLowerCase();
    if (s) {
      filtered = filtered.filter(
        (p) =>
          p.name?.toLowerCase().includes(s) ||
          p.description?.toLowerCase().includes(s) ||
          p.category?.toLowerCase().includes(s)
      );
    }
    if (selectedCategory !== 'All') {
      filtered = filtered.filter((p) => p.category === selectedCategory);
    }
    switch (sortBy) {
      case 'price-low':
        filtered.sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        filtered.sort((a, b) => b.price - a.price);
        break;
      case 'name':
        filtered.sort((a, b) => a.name.localeCompare(b.name));
        break;
      case 'popular':
        filtered.sort((a, b) => (b.analytics?.views || 0) - (a.analytics?.views || 0));
        break;
      case 'newest':
      default:
        filtered.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
        break;
    }
    setFilteredProducts(filtered);
  }, [products, searchTerm, selectedCategory, sortBy]);

  // Favorites
  useEffect(() => {
    try {
      const saved = localStorage.getItem('favorites');
      if (saved) setFavorites(new Set(JSON.parse(saved)));
    } catch {}
  }, []);

  const paymentMethods = useMemo(() => {
    const raw =
      sellerData?.paymentMethods ||
      sellerData?.payments ||
      sellerData?.paymentOptions ||
      [];
    if (Array.isArray(raw)) return raw.filter(Boolean);
    if (raw && typeof raw === 'object') {
      return Object.entries(raw)
        .filter(([, v]) => !!v)
        .map(([k]) => k);
    }
    return [];
  }, [sellerData]);

  const deliveryOptions = useMemo(() => {
    const raw =
      sellerData?.deliveryOptions ||
      sellerData?.shippingOptions ||
      sellerData?.deliveryMethods ||
      [];
    if (Array.isArray(raw)) return raw.filter(Boolean);
    if (raw && typeof raw === 'object') {
      return Object.entries(raw)
        .filter(([, v]) => !!v)
        .map(([k]) => k);
    }
    return [];
  }, [sellerData]);

  // Actions
  const handleContactSeller = async (product) => {
    await trackInteraction(sellerId, product.productId, 'contact');
    const productUrl = `${window.location.origin}/store/${sellerId}#${product.productId}`;
    const message = createWhatsAppMessage.productInquiry(product, sellerData, productUrl);
    const whatsappUrl = generateWhatsAppUrl(sellerData.whatsappNumber, message);
    if (isMobileDevice()) {
      window.location.href = whatsappUrl;
      setTimeout(() => setContactNotification({ show: true, product }), 1000);
    } else {
      window.open(whatsappUrl, '_blank');
    }
  };

  const handleFloatingChatClick = () => {
    if (!sellerData?.whatsappNumber) return;
    const storeUrl = `${window.location.origin}/store/${sellerId}`;
    const msg = createWhatsAppMessage.storeShare(sellerData, storeUrl);
    const url = generateWhatsAppUrl(sellerData.whatsappNumber, msg);
    if (isMobileDevice()) window.location.href = url;
    else window.open(url, '_blank');
  };

  const handleMarketingClick = () => {
    try {
      window.gtag?.('event', 'marketing_cta_click', { sellerId });
    } catch {}
  };

  const handleToggleFavorite = (productId, e) => {
    e.stopPropagation();
    const s = new Set(favorites);
    s.has(productId) ? s.delete(productId) : s.add(productId);
    setFavorites(s);
    try {
      localStorage.setItem('favorites', JSON.stringify([...s]));
    } catch {}
    const btn = e.target?.closest?.('button');
    if (btn) {
      btn.style.animation = 'heartBeat 0.6s ease-in-out';
      setTimeout(() => (btn.style.animation = ''), 600);
    }
  };

  const handleProductView = async (product) => {
    await trackInteraction(sellerId, product.productId, 'view');
    setSelectedProduct(product);
    setShowProductModal(true);
  };

  // Close modals on ESC
  useEffect(() => {
    const onKey = (e) => {
      if (e.key === 'Escape') {
        setShowPaymentModal(false);
        setShowDeliveryModal(false);
        setShowProductModal(false);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  // Loading / error UIs
  if (loading) {
    return (
      <div
        style={{
          minHeight: '100vh',
          display: 'grid',
          placeItems: 'center',
          background: 'linear-gradient(180deg,#eef2ff 0%,#e0f2fe 50%,#e6fffb 100%)',
        }}
      >
        <div
          style={{
            background: 'rgba(255,255,255,0.9)',
            padding: 40,
            borderRadius: 16,
            textAlign: 'center',
          }}
        >
          <div
            style={{
              width: 32,
              height: 32,
              border: '3px solid #eee',
              borderTop: '3px solid #5a6bff',
              borderRadius: '50%',
              animation: 'spin 1s linear infinite',
              margin: '0 auto 16px',
            }}
          />
          <p className="typ-body">Loading store...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div
        style={{
          minHeight: '100vh',
          display: 'grid',
          placeItems: 'center',
          background: 'linear-gradient(180deg,#eef2ff 0%,#e0f2fe 50%,#e6fffb 100%)',
        }}
      >
        <div
          style={{
            background: 'rgba(255,255,255,0.9)',
            padding: 40,
            borderRadius: 16,
            textAlign: 'center',
          }}
        >
          <h2 style={{ color: '#dc2626', marginBottom: 16 }}>Store Not Found</h2>
          <p className="typ-body" style={{ marginBottom: 24 }}>{error}</p>
          <button
            onClick={() => window.history.back()}
            style={{
              padding: '12px 24px',
              background: '#5a6bff',
              color: '#fff',
              border: 'none',
              borderRadius: 8,
              cursor: 'pointer',
              display: 'inline-flex',
              alignItems: 'center',
              gap: 8,
            }}
          >
            <ArrowLeft size={16} /> Go Back
          </button>
        </div>
      </div>
    );
  }

  // Friendly label helpers for chip modals
  const labelForPayment = (k) => {
    const key = String(k || '').toLowerCase();
    if (/momo|mobile/.test(key)) return 'Mobile Money';
    if (/card/.test(key)) return 'Card';
    if (/bank/.test(key)) return 'Bank Transfer';
    if (/cash/.test(key)) return 'Cash';
    if (/pos/.test(key)) return 'POS';
    if (/paypal/.test(key)) return 'PayPal';
    return k;
  };
  const iconForPayment = (k) => {
    const key = String(k || '').toLowerCase();
    if (/momo|mobile/.test(key)) return '📱';
    if (/card/.test(key)) return '💳';
    if (/bank/.test(key)) return '🏦';
    if (/cash/.test(key)) return '💵';
    if (/pos/.test(key)) return '🧾';
    if (/paypal/.test(key)) return '🅿️';
    return '💳';
  };
  const labelForDelivery = (k) => {
    const key = String(k || '').toLowerCase();
    if (/pickup|pick-up|self/.test(key)) return 'Pickup';
    if (/local/.test(key)) return 'Local Delivery';
    if (/courier|rider/.test(key)) return 'Courier';
    if (/nation/.test(key)) return 'Nationwide';
    if (/inter/.test(key)) return 'International';
    return k;
  };
  const iconForDelivery = (k) => {
    const key = String(k || '').toLowerCase();
    if (/pickup|pick-up|self/.test(key)) return '🧍';
    if (/local/.test(key)) return '🚲';
    if (/courier|rider/.test(key)) return '🚚';
    if (/nation/.test(key)) return '🛣️';
    if (/inter/.test(key)) return '✈️';
    return '🚚';
  };

  return (
    <>
      <div
        style={{
          minHeight: '100vh',
          background: 'linear-gradient(180deg,#eef2ff 0%,#e0f2fe 50%,#e6fffb 100%)',
          padding: 20,
        }}
      >
        <style>{`
          @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
          @keyframes heartBeat { 0% { transform: scale(1); } 50% { transform: scale(1.2); } 100% { transform: scale(1); } }
          @keyframes slideUp { from { transform: translateY(10px); opacity: 0; } to { transform: translateY(0); opacity: 1); } }
          @keyframes pulse { 0% { opacity: 1; } 50% { opacity: .7; } 100% { opacity: 1; } }
        `}</style>

        <div style={{ maxWidth: 980, margin: '0 auto' }}>
          {/* ===== Header / Banner ===== */}
          <div
            style={{
              background: 'rgba(255,255,255,0.95)',
              borderRadius: 20,
              padding: '0 0 24px',
              marginBottom: 24,
              boxShadow: '0 10px 30px rgba(0,0,0,0.06)',
            }}
          >
            <div
              style={{
                height: 160,
                borderTopLeftRadius: 20,
                borderTopRightRadius: 20,
                background: sellerData?.bannerUrl
                  ? `url(${sellerData.bannerUrl}) center/cover no-repeat`
                  : 'linear-gradient(135deg,#c7d2fe 0%,#bae6fd 60%,#ccfbf1 100%)',
              }}
            />
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: 16,
                padding: '0 24px',
                marginTop: -30,
              }}
            >
              <div
                style={{
                  width: 72,
                  height: 72,
                  borderRadius: '50%',
                  background: 'linear-gradient(135deg,#5a6bff,#67d1ff)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: 28,
                  boxShadow: '0 6px 18px rgba(0,0,0,0.12)',
                  border: '3px solid #fff',
                }}
              >
                🛍️
              </div>
              <div style={{ flex: 1 }}>
                <h1 className="typ-title" style={{ fontSize: 28, margin: '0 0 4px' }}>
                  {sellerData?.storeName || 'Store'}
                </h1>
                <p className="typ-meta" style={{ margin: 0 }}>
                  {sellerData?.location || 'Online Store'}
                </p>
              </div>
            </div>

            {/* chips */}
            <div
              style={{
                display: 'flex',
                gap: 12,
                flexWrap: 'wrap',
                padding: '12px 24px 0',
              }}
            >
              {paymentMethods.length > 0 && (
                <button
                  onClick={() => setShowPaymentModal(true)}
                  style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: 8,
                    background: '#eef2ff',
                    color: '#374151',
                    padding: '10px 14px',
                    borderRadius: 999,
                    fontWeight: 700,
                    border: '1px solid #e5e7eb',
                    cursor: 'pointer',
                  }}
                  title="View payment methods"
                >
                  💳 {paymentMethods.length} Payment Methods
                </button>
              )}
              {deliveryOptions.length > 0 && (
                <button
                  onClick={() => setShowDeliveryModal(true)}
                  style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: 8,
                    background: '#ecfeff',
                    color: '#374151',
                    padding: '10px 14px',
                    borderRadius: 999,
                    fontWeight: 700,
                    border: '1px solid #e5e7eb',
                    cursor: 'pointer',
                  }}
                  title="View delivery options"
                >
                  🚚 {deliveryOptions.length} Delivery Options
                </button>
              )}
              {sellerData?.currency && (
                <div
                  className="typ-meta"
                  style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: 8,
                    background: '#f3f4f6',
                    color: '#4b5563',
                    padding: '10px 14px',
                    borderRadius: 999,
                    fontWeight: 700,
                    border: '1px solid #e5e7eb',
                  }}
                >
                  🌐 {sellerData.currency} Currency
                </div>
              )}
            </div>

            {/* Store description */}
            {(sellerData?.storeDescription) && (
              <p
                className="typ-body"
                style={{
                  margin: '8px 24px 0',
                  color: '#374151',
                  lineHeight: 1.5,
                  display: '-webkit-box',
                  WebkitLineClamp: 2,
                  WebkitBoxOrient: 'vertical',
                  overflow: 'hidden',
                }}
              >
                {sellerData.storeDescription}
              </p>
            )}

            {/* Action pills */}
            <div
              style={{
                display: 'flex',
                gap: 12,
                justifyContent: 'center',
                flexWrap: 'wrap',
                padding: '12px 24px',
              }}
            >
              <button
                onClick={handleFloatingChatClick}
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: 8,
                  background: 'rgba(37,211,102,0.12)',
                  color: '#25D366',
                  padding: '8px 16px',
                  borderRadius: 999,
                  fontSize: 14,
                  fontWeight: 600,
                  border: '1px solid rgba(37,211,102,0.25)',
                  cursor: 'pointer',
                }}
              >
                <MessageCircle size={16} /> Chat with seller on WhatsApp
              </button>

              <a
                href={`${SHOPLINK_SIGNUP_URL}?utm_source=storefront&utm_medium=header_badge&utm_campaign=public_cta&seller=${sellerId}`}
                target="_blank"
                rel="noopener noreferrer"
                onClick={handleMarketingClick}
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: 8,
                  background: 'rgba(59,130,246,0.12)',
                  color: '#3b82f6',
                  padding: '8px 16px',
                  borderRadius: 999,
                  fontSize: 14,
                  fontWeight: 700,
                  border: '1px solid rgba(59,130,246,0.25)',
                  textDecoration: 'none',
                  cursor: 'pointer',
                }}
              >
                ✨ Create your free ShopLink store
              </a>

              <div
                className="typ-meta"
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: 8,
                  background: 'rgba(59,130,246,0.12)',
                  color: '#3b82f6',
                  padding: '8px 16px',
                  borderRadius: 999,
                  fontSize: 14,
                  fontWeight: 600,
                  border: '1px solid rgba(59,130,246,0.25)',
                }}
              >
                ⚡ Usually responds within 2 hours
              </div>
            </div>
          </div>

          {/* ===== Filters ===== */}
          <div
            style={{
              background: 'rgba(255,255,255,0.95)',
              borderRadius: 16,
              padding: 24,
              marginBottom: 24,
              boxShadow: '0 8px 22px rgba(0,0,0,0.05)',
            }}
          >
            <div style={{ marginBottom: 20 }}>
              <input
                type="text"
                placeholder="Search products..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                style={{
                  width: '100%',
                  padding: '12px 16px',
                  border: '2px solid #e5e7eb',
                  borderRadius: 12,
                  fontSize: 16,
                  outline: 'none',
                  transition: 'border-color .2s',
                }}
                onFocus={(e) => (e.target.style.borderColor = '#5a6bff')}
                onBlur={(e) => (e.target.style.borderColor = '#e5e7eb')}
              />
            </div>

            <div
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                flexWrap: 'wrap',
                gap: 16,
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                <span className="typ-meta" style={{ fontWeight: 600 }}>
                  Categories:
                </span>
                {['All', ...new Set(products.map((p) => p.category).filter(Boolean))].map(
                  (category) => (
                    <button
                      key={category}
                      onClick={() => setSelectedCategory(category)}
                      className="typ-meta"
                      style={{
                        padding: '6px 12px',
                        borderRadius: 20,
                        border: 'none',
                        cursor: 'pointer',
                        transition: 'all .2s',
                        background: selectedCategory === category ? '#5a6bff' : '#f3f4f6',
                        color: selectedCategory === category ? '#fff' : '#6b7280',
                      }}
                    >
                      {category}{' '}
                      {category !== 'All' &&
                        `(${products.filter((p) => p.category === category).length})`}
                    </button>
                  )
                )}
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span className="typ-meta" style={{ fontWeight: 600 }}>
                  Sort by:
                </span>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="typ-meta"
                  style={{
                    padding: '8px 12px',
                    borderRadius: 8,
                    border: '2px solid #e5e7eb',
                    cursor: 'pointer',
                    outline: 'none',
                  }}
                >
                  <option value="newest">Newest</option>
                  <option value="popular">Most Popular</option>
                  <option value="price-low">Price: Low to High</option>
                  <option value="price-high">Price: High to Low</option>
                  <option value="name">Name A-Z</option>
                </select>
              </div>
            </div>

            <div className="typ-meta" style={{ marginTop: 16 }}>
              Showing {filteredProducts.length} of {products.length} products
              {searchTerm && ` for "${searchTerm}"`}
              {selectedCategory !== 'All' && ` in ${selectedCategory}`}
            </div>
          </div>

          {/* ===== Products Grid ===== */}
          {filteredProducts.length > 0 ? (
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
                gap: 24,
              }}
            >
              {filteredProducts.map((product) => (
                <ProductCard
                  key={product.productId}
                  product={product}
                  sellerCurrency={sellerData?.currency}
                  onContact={handleContactSeller}
                  onView={handleProductView}
                  onToggleFavorite={handleToggleFavorite}
                  isFavorited={favorites.has(product.productId)}
                  isLoading={false}
                />
              ))}
            </div>
          ) : (
            <div
              style={{
                background: 'rgba(255,255,255,0.95)',
                borderRadius: 16,
                padding: 60,
                textAlign: 'center',
              }}
            >
              <h3 className="typ-title" style={{ opacity: 0.7, margin: '0 0 8px' }}>
                {products.length === 0 ? 'No products available' : 'No products found'}
              </h3>
              <p className="typ-meta" style={{ margin: 0 }}>
                {products.length === 0
                  ? 'This store is being set up. Check back soon!'
                  : 'Try adjusting your search or filters.'}
              </p>
              {(searchTerm || selectedCategory !== 'All') && (
                <button
                  onClick={() => {
                    setSearchTerm('');
                    setSelectedCategory('All');
                  }}
                  style={{
                    marginTop: 16,
                    padding: '8px 16px',
                    background: '#5a6bff',
                    color: '#fff',
                    border: 'none',
                    borderRadius: 8,
                    cursor: 'pointer',
                  }}
                >
                  Clear filters
                </button>
              )}
            </div>
          )}

          {/* Footer */}
          <div style={{ textAlign: 'center', marginTop: 40, padding: 20, opacity: 0.6 }}>
            <p className="typ-meta" style={{ margin: 0 }}>
              Powered by 🛍️ ShopLink —{' '}
              <a
                href={`${SHOPLINK_SIGNUP_URL}?utm_source=storefront&utm_medium=footer&utm_campaign=public_cta&seller=${sellerId}`}
                target="_blank"
                rel="noopener noreferrer"
                onClick={handleMarketingClick}
                style={{ color: '#5a6bff', fontWeight: 700, textDecoration: 'none' }}
              >
                create your store
              </a>
            </p>
          </div>
        </div>
      </div>

      {/* Floating WhatsApp FAB */}
      {showChatFab && (
        <button
          className="whatsapp-fab"
          onClick={handleFloatingChatClick}
          aria-label="Chat with seller on WhatsApp"
          title="Chat with seller on WhatsApp"
        >
          <span
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              justifyContent: 'center',
              width: 22,
              height: 22,
              background: 'rgba(255,255,255,.22)',
              borderRadius: '50%',
              fontSize: 14,
              lineHeight: 1,
            }}
          >
            ✆
          </span>
          <span style={{ fontWeight: 800 }}>Chat</span>
        </button>
      )}

      {/* Contact confirmation (mobile) */}
      {contactNotification.show && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            background: 'rgba(0,0,0,0.6)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 1000,
            padding: 20,
          }}
        >
          <div
            style={{
              background: 'white',
              borderRadius: 20,
              maxWidth: 400,
              width: '100%',
              padding: '32px 24px',
              textAlign: 'center',
            }}
          >
            <div
              style={{
                width: 64,
                height: 64,
                margin: '0 auto 24px',
                background: 'rgba(37,211,102,0.1)',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <MessageCircle size={32} style={{ color: '#25D366' }} />
            </div>
            <h2 className="typ-title" style={{ margin: '0 0 12px' }}>Welcome Back!</h2>
            <p className="typ-body" style={{ margin: '0 0 32px' }}>
              Your WhatsApp message has been sent. Continue browsing for more great products!
            </p>
            <div style={{ display: 'flex', justifyContent: 'center' }}>
              <button
                onClick={() => setContactNotification({ show: false, product: null })}
                style={{
                  padding: '12px 32px',
                  background: '#5a6bff',
                  color: '#fff',
                  border: 'none',
                  borderRadius: 12,
                  fontSize: 16,
                  fontWeight: 600,
                  cursor: 'pointer',
                }}
              >
                Continue Browsing
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Payment Methods modal */}
      {showPaymentModal && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="payment-modal-title"
          onClick={(e) => e.currentTarget === e.target && setShowPaymentModal(false)}
          style={{
            position: 'fixed',
            inset: 0,
            background: 'rgba(0,0,0,0.6)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 1600,
            padding: 20,
          }}
        >
          <div
            style={{
              background: '#fff',
              borderRadius: 16,
              width: '100%',
              maxWidth: 480,
              boxShadow: '0 20px 60px rgba(0,0,0,.25)',
            }}
          >
            <div
              style={{
                padding: 20,
                borderBottom: '1px solid #e5e7eb',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
              }}
            >
              <h3 id="payment-modal-title" className="typ-title" style={{ margin: 0 }}>
                Accepted Payment Methods
              </h3>
              <button
                onClick={() => setShowPaymentModal(false)}
                aria-label="Close"
                style={{
                  background: '#f3f4f6',
                  border: 'none',
                  borderRadius: '50%',
                  width: 36,
                  height: 36,
                  cursor: 'pointer',
                }}
              >
                ×
              </button>
            </div>
            <div style={{ padding: 20 }}>
              {paymentMethods.map((m) => (
                <div
                  key={m}
                  className="typ-body"
                  style={{
                    padding: '10px 12px',
                    border: '1px solid #e5e7eb',
                    borderRadius: 12,
                    marginBottom: 10,
                    display: 'flex',
                    alignItems: 'center',
                    gap: 10,
                  }}
                >
                  <span style={{ fontSize: 18 }}>{iconForPayment(m)}</span>
                  <span style={{ fontWeight: 700 }}>{labelForPayment(m)}</span>
                </div>
              ))}
              {paymentMethods.length === 0 && (
                <p className="typ-meta" style={{ margin: 0 }}>
                  The seller hasn’t listed payment methods. Please ask on WhatsApp.
                </p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Delivery Options modal */}
      {showDeliveryModal && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="delivery-modal-title"
          onClick={(e) => e.currentTarget === e.target && setShowDeliveryModal(false)}
          style={{
            position: 'fixed',
            inset: 0,
            background: 'rgba(0,0,0,0.6)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 1600,
            padding: 20,
          }}
        >
          <div
            style={{
              background: '#fff',
              borderRadius: 16,
              width: '100%',
              maxWidth: 480,
              boxShadow: '0 20px 60px rgba(0,0,0,.25)',
            }}
          >
            <div
              style={{
                padding: 20,
                borderBottom: '1px solid #e5e7eb',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
              }}
            >
              <h3 id="delivery-modal-title" className="typ-title" style={{ margin: 0 }}>
                Delivery Options
              </h3>
              <button
                onClick={() => setShowDeliveryModal(false)}
                aria-label="Close"
                style={{
                  background: '#f3f4f6',
                  border: 'none',
                  borderRadius: '50%',
                  width: 36,
                  height: 36,
                  cursor: 'pointer',
                }}
              >
                ×
              </button>
            </div>
            <div style={{ padding: 20 }}>
              {deliveryOptions.map((d) => (
                <div
                  key={d}
                  className="typ-body"
                  style={{
                    padding: '10px 12px',
                    border: '1px solid #e5e7eb',
                    borderRadius: 12,
                    marginBottom: 10,
                    display: 'flex',
                    alignItems: 'center',
                    gap: 10,
                  }}
                >
                  <span style={{ fontSize: 18 }}>{iconForDelivery(d)}</span>
                  <span style={{ fontWeight: 700 }}>{labelForDelivery(d)}</span>
                </div>
              ))}
              {deliveryOptions.length === 0 && (
                <p className="typ-meta" style={{ margin: 0 }}>
                  The seller hasn’t listed delivery options. Please ask on WhatsApp.
                </p>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Product detail modal */}
      {showProductModal && selectedProduct && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            background: 'rgba(0,0,0,0.8)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 2000,
            padding: 20,
          }}
        >
          <div
            style={{
              background: 'white',
              borderRadius: 20,
              maxWidth: 600,
              width: '100%',
              maxHeight: '90vh',
              overflow: 'auto',
            }}
          >
            <div
              style={{
                padding: 24,
                borderBottom: '1px solid #e5e7eb',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'flex-start',
                gap: 16,
              }}
            >
              <div style={{ flex: 1 }}>
                <h2 className="typ-title" style={{ margin: '0 0 8px' }}>
                  {selectedProduct.name}
                </h2>
                {selectedProduct.category && (
                  <span
                    className="typ-meta"
                    style={{
                      background: '#f3f4f6',
                      color: '#6b7280',
                      padding: '4px 12px',
                      borderRadius: 20,
                      fontWeight: 600,
                    }}
                  >
                    📦 {selectedProduct.category}
                  </span>
                )}
              </div>
              <button
                onClick={() => setShowProductModal(false)}
                style={{
                  background: '#f3f4f6',
                  border: 'none',
                  borderRadius: '50%',
                  width: 40,
                  height: 40,
                  fontSize: 20,
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: '#6b7280',
                }}
              >
                ×
              </button>
            </div>

            <div style={{ padding: 24 }}>
              <div
                style={{
                  position: 'relative',
                  marginBottom: 24,
                  width: '100%',
                  aspectRatio: '4 / 3',
                  background: '#f8fafc',
                  borderRadius: 16,
                  overflow: 'hidden',
                  boxShadow: '0 8px 24px rgba(0,0,0,0.1)',
                }}
              >
                <img
                  src={getProductImageUrl(selectedProduct)}
                  alt={selectedProduct.name}
                  onLoad={(e) => handleImageLoad(selectedProduct.productId, e)}
                  onError={handleImageError}
                  style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover' }}
                />
                {lowResImages[selectedProduct.productId] && (
                  <div
                    className="typ-meta"
                    style={{
                      position: 'absolute',
                      top: 16,
                      right: 16,
                      background: 'rgba(255,255,255,0.95)',
                      color: '#dc2626',
                      padding: '6px 12px',
                      borderRadius: 999,
                      fontWeight: 700,
                    }}
                  >
                    Low-res image
                  </div>
                )}
              </div>

              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  marginBottom: 24,
                  padding: 20,
                  background: 'linear-gradient(135deg,#f0f9ff,#e0f2fe)',
                  borderRadius: 16,
                  border: '1px solid #e0f2fe',
                }}
              >
                <div>
                  <div style={{ fontSize: 32, fontWeight: 800, color: '#059669', marginBottom: 4 }}>
                    {formatPrice(selectedProduct.price, sellerData?.currency)}
                  </div>
                  <div className="typ-meta">Price per unit</div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div
                    style={{
                      fontSize: 20,
                      fontWeight: 700,
                      color:
                        selectedProduct.quantity > 10 ? '#059669' :
                        selectedProduct.quantity > 0  ? '#f59e0b' : '#ef4444',
                      marginBottom: 4,
                    }}
                  >
                    {selectedProduct.quantity} {selectedProduct.quantity === 1 ? 'unit' : 'units'}
                  </div>
                  <div
                    className="typ-meta"
                    style={{
                      padding: '4px 12px',
                      borderRadius: 20,
                      fontWeight: 600,
                      display: 'inline-block',
                      background:
                        selectedProduct.quantity > 10 ? '#dcfce7' :
                        selectedProduct.quantity > 0  ? '#fef3c7' : '#fee2e2',
                      color:
                        selectedProduct.quantity > 10 ? '#059669' :
                        selectedProduct.quantity > 0  ? '#f59e0b' : '#ef4444',
                    }}
                  >
                    {selectedProduct.quantity > 10
                      ? '✅ In Stock'
                      : selectedProduct.quantity > 0
                      ? '⚠️ Low Stock'
                      : '❌ Out of Stock'}
                  </div>
                </div>
              </div>

              {selectedProduct.description && (
                <div style={{ marginBottom: 24 }}>
                  <h3 className="typ-title" style={{ margin: '0 0 12px' }}>📝 Description</h3>
                  <p className="typ-body" style={{ margin: 0 }}>{selectedProduct.description}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default StorefrontPublicView;
