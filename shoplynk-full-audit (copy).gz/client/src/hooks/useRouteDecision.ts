import { useEffect, useRef } from 'react';
import { useLocation } from 'wouter';
import { useOnboardingProgress } from './useOnboardingProgress';

// Debug flag for development
declare global {
  interface Window {
    __debugOnboarding?: boolean;
  }
}

export function useRouteDecision() {
  const { loading, error, firstIncompleteStep, isComplete } = useOnboardingProgress();
  const [, navigate] = useLocation();
  const redirected = useRef(false);
  const ready = !loading;

  useEffect(() => {
    // Don't redirect if not ready or already redirected
    if (!ready || redirected.current) return;

    const path = window.location.pathname;
    const search = new URLSearchParams(window.location.search);
    const requestedStep = Number.parseInt(search.get('step') ?? '1', 10);

    const debug = window.__debugOnboarding;
    
    if (debug) {
      console.debug('RouteDecision:', {
        path,
        ready,
        isComplete,
        firstIncompleteStep,
        requestedStep,
        error
      });
    }

    const go = (to: string, reason: string) => {
      redirected.current = true;
      if (debug) {
        console.debug(`Redirecting to ${to} - Reason: ${reason}`);
      }
      navigate(to, { replace: true });
    };

    // Handle errors
    if (error) {
      console.error('Onboarding error:', error);
      if (path !== '/auth') go('/auth', 'Error loading user data');
      return;
    }

    // Allow marketing landing page and public routes for all users
    if (path === '/' || path.startsWith('/features') || path.startsWith('/pricing') || path.startsWith('/support') || path.startsWith('/faq') || path.startsWith('/terms') || path.startsWith('/privacy')) {
      return; // Don't redirect, let them browse
    }

    // Completed onboarding
    if (isComplete) {
      if (path !== '/dashboard' && !path.startsWith('/products') && !path.startsWith('/analytics') && !path.startsWith('/orders') && !path.startsWith('/settings') && !path.startsWith('/storefront')) {
        go('/dashboard', 'Onboarding completed');
      }
      return;
    }

    // In progress or not started - ensure correct step
    const shouldBe = `/onboarding/${firstIncompleteStep}`;
    const currentOnboarding = path.startsWith('/onboarding');
    
    if (!currentOnboarding) {
      go(shouldBe, `Should be on ${firstIncompleteStep}, currently on ${path}`);
    }
  }, [ready, isComplete, firstIncompleteStep, navigate, error]);

  return { ready, redirected: redirected.current };
}