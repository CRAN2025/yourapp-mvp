import { useEffect } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '@/hooks/use-auth';
import { useOnboardingProgress } from '@/hooks/useOnboardingProgress';
import LoadingSpinner from './LoadingSpinner';

interface OnboardingGuardProps {
  children: React.ReactNode;
  requiredStep?: number;
}

export function OnboardingGuard({ children, requiredStep }: OnboardingGuardProps) {
  const { user, loading: authLoading } = useAuth();
  const { loading: onboardingLoading, isComplete, firstIncompleteStep } = useOnboardingProgress();
  const [, navigate] = useLocation();

  useEffect(() => {
    // Wait for auth and onboarding data to load
    if (authLoading || onboardingLoading) return;

    // Not authenticated - redirect to auth
    if (!user) {
      navigate('/auth');
      return;
    }

    // If onboarding is completed, redirect to dashboard
    if (isComplete) {
      navigate('/dashboard');
      return;
    }

    // If a specific step is required, ensure it's accessible
    if (requiredStep !== undefined) {
      // Redirect to first incomplete step if trying to access later step
      navigate(`/onboarding/${firstIncompleteStep}`);
      return;
    }
  }, [user, isComplete, firstIncompleteStep, authLoading, onboardingLoading, requiredStep, navigate]);

  // Show loading while checking authentication and onboarding state
  if (authLoading || onboardingLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  // Don't render children if user will be redirected
  if (!user || isComplete) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return <>{children}</>;
}